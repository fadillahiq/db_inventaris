--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.ruang DROP CONSTRAINT ruang_pkey;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY public.pegawai DROP CONSTRAINT pegawai_pkey;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.jenis DROP CONSTRAINT jenis_pkey;
ALTER TABLE ONLY public.inventaris DROP CONSTRAINT inventaris_pkey;
ALTER TABLE ONLY public.detail_pinjaman DROP CONSTRAINT detail_pinjaman_pkey;
DROP TABLE public.ruang;
DROP TABLE public.petugas;
DROP TABLE public.peminjaman;
DROP TABLE public.pegawai;
DROP TABLE public.level;
DROP TABLE public.jenis;
DROP TABLE public.inventaris;
DROP TABLE public.detail_pinjaman;
DROP TYPE public.status_peminjaman;
DROP TYPE public.kondisi;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: kondisi; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE kondisi AS ENUM (
    'Selesai',
    'Belum'
);


ALTER TYPE kondisi OWNER TO postgres;

--
-- Name: status_peminjaman; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status_peminjaman AS ENUM (
    'Selesai',
    'Belum'
);


ALTER TYPE status_peminjaman OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_pinjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_pinjaman (
    id_detail_pinjaman character varying(20) NOT NULL,
    id_inventaris character varying(20),
    jumlah integer
);


ALTER TABLE detail_pinjaman OWNER TO postgres;

--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventaris (
    id_inventaris character varying(20) NOT NULL,
    nama character varying(100),
    kondisi kondisi,
    keterangan text,
    jumlah integer,
    id_jenis character varying(20),
    tanggal_register date,
    id_ruang character varying(20),
    kode_inventaris character varying(20),
    id_petugas character varying(20)
);


ALTER TABLE inventaris OWNER TO postgres;

--
-- Name: jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE jenis (
    id_jenis character varying(20) NOT NULL,
    nama_jenis character varying(100),
    kode_jenis character varying(20),
    keterangan text
);


ALTER TABLE jenis OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level character varying(20) NOT NULL,
    nama_level character varying(100)
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: pegawai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pegawai (
    id_pegawai character varying(20) NOT NULL,
    nama_pegawai character varying(100),
    nip character varying(20),
    alamat text
);


ALTER TABLE pegawai OWNER TO postgres;

--
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE peminjaman (
    id_peminjaman character varying(20) NOT NULL,
    tanggal_peminjaman date,
    tanggal_kembali date,
    status_peminjaman status_peminjaman,
    id_pegawai character varying(20)
);


ALTER TABLE peminjaman OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas character varying(20) NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_petugas character varying(100),
    id_level character varying(20)
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE ruang (
    id_ruang character varying(20) NOT NULL,
    nama_ruang character varying(100),
    kode_ruang character varying(20),
    keterangan character varying(100)
);


ALTER TABLE ruang OWNER TO postgres;

--
-- Data for Name: detail_pinjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_pinjaman (id_detail_pinjaman, id_inventaris, jumlah) FROM stdin;
\.
COPY detail_pinjaman (id_detail_pinjaman, id_inventaris, jumlah) FROM '$$PATH$$/2845.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2844.dat';

--
-- Data for Name: jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2842.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level) FROM stdin;
\.
COPY level (id_level, nama_level) FROM '$$PATH$$/2847.dat';

--
-- Data for Name: pegawai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM stdin;
\.
COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM '$$PATH$$/2849.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY peminjaman (id_peminjaman, tanggal_peminjaman, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY peminjaman (id_peminjaman, tanggal_peminjaman, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2848.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2846.dat';

--
-- Data for Name: ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2843.dat';

--
-- Name: detail_pinjaman detail_pinjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjaman
    ADD CONSTRAINT detail_pinjaman_pkey PRIMARY KEY (id_detail_pinjaman);


--
-- Name: inventaris inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris
    ADD CONSTRAINT inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: jenis jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis
    ADD CONSTRAINT jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: pegawai pegawai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pegawai
    ADD CONSTRAINT pegawai_pkey PRIMARY KEY (id_pegawai);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: ruang ruang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang
    ADD CONSTRAINT ruang_pkey PRIMARY KEY (id_ruang);


--
-- PostgreSQL database dump complete
--

